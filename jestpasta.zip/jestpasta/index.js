function isEven(numero) {
    return numero % 2 == 0
}

module.exports = isEven