function Header(){
    return(
<header>
    <h1>Página do Camaleão</h1>
  </header>
    )
}
 
export default Header