
import './App.css'
import Header from './components/Header'

function App() {

  return (
    <div>
      <Header/>
   <section>
    <img src="./camaleao.jpg" alt="" />
  </section>
  <section>
    <h2>Sobre</h2>
    <p>Seja bem vindo(a)!!! Nessa página web, temos o objetivo de espalhar cores pelo mundo, com o poder dos camaleões!!!</p>
  </section>
  </div>
  )
}

export default App
