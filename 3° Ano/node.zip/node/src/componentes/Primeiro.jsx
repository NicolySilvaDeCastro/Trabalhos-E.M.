import React from "react"

//Arrow Function
export default props => (
<h1>Bom dia {props.name}!</h1>
)

/*export default function(){
    return <h1>Teste</h1>
}
*/