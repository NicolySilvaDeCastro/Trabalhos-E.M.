import React from "react"
import ReactDOM from "react-dom"

import Bomdia from "./componentes/Primeiro"

ReactDOM.render(<Bomdia name="Princesa"/>, document.getElementById('root'))


/*import React from "react"
import ReactDOM from "react-dom"

const elemento = <h1>React exemplo de elemento</h1>

ReactDOM.render(elemento, document.getElementById('root'))*/