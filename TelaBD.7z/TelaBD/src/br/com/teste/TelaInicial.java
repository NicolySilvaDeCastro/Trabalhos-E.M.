package br.com.teste;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class TelaInicial extends JFrame {
	
	public TelaInicial() {
		super("Tela de cadastro");
		setSize(550, 450);
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		JLabel jLTitulo = new JLabel("Cadastro de Clientes - 3C");
		jLTitulo.setBounds(100, 5, 850, 60);
		jLTitulo.setFont(new Font("Arial", Font.BOLD, 25));
		add(jLTitulo);
		JLabel jbID = new JLabel("ID:");	
		jbID.setBounds(400, 50, 850, 60);
		add(jbID);
		JTextField jtID = new JTextField();
		jtID.setBounds(470, 70, 20, 20);
		jtID.setEnabled(false);
		add(jtID);		
		JLabel jbNome = new JLabel("Nome:");	
		jbNome.setBounds(10, 50, 850, 60);
		add(jbNome);
		JTextField jtNome = new JTextField();
		jtNome.setBounds(70, 70, 200, 20);
		add(jtNome);
		JLabel jbemail = new JLabel("e-mail:");	
		jbemail.setBounds(10, 100, 850, 60);
		add(jbemail);
		JTextField jtEmail = new JTextField();
		jtEmail.setBounds(70, 120, 300, 20);
		add(jtEmail);
		JLabel jlTelefone = new JLabel("telefone:");	
		jlTelefone.setBounds(10, 150, 850, 60);
		add(jlTelefone);
		JTextField jtTelefone = new JTextField();
		jtTelefone.setBounds(70, 170, 100, 20);
		add(jtTelefone);
		JLabel jlCPF = new JLabel("CPF:");	
		jlCPF.setBounds(10, 200, 850, 60);
		add(jlCPF);
		JTextField jtCPF = new JTextField();
		jtCPF.setBounds(70, 220, 100, 20);
		add(jtCPF);
		JLabel jlEnd = new JLabel("Endereço:");
		jlEnd.setBounds(10, 250, 100, 60);
		add(jlEnd);
		JTextField jtEnd = new JTextField();
		jtEnd.setBounds(70, 270, 350, 20);
		add(jtEnd);
		JButton jbCadastro = new JButton("Cadastrar");
		jbCadastro.setBounds(10, 300, 100, 20);
		jbCadastro.setVisible(true);
		add(jbCadastro);
		JButton jbExibe = new JButton("Pesquisar");
		jbExibe.setBounds(120, 300, 100, 20);
		jbExibe.setVisible(true);
		add(jbExibe);
		JButton jbAtualiza = new JButton("Modificar");
		jbAtualiza.setBounds(230, 300, 100, 20);
		jbAtualiza.setVisible(true);
		jbAtualiza.setEnabled(false);
		add(jbAtualiza);
		setVisible(true);
		
		BDUtil bd = new BDUtil();
		
		jbCadastro.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				try {					
					bd.sql = "INSERT INTO cliente(nome, telefone, email, cpf, endereco) VALUES(?, ?, ?, ?, ?)";
					bd.preparaBD();
					bd.preparedStatement.setString(1, jtNome.getText().toUpperCase());
					bd.preparedStatement.setString(2, jtTelefone.getText());
					bd.preparedStatement.setString(3, jtEmail.getText());
					bd.preparedStatement.setString(4, jtCPF.getText());		
					bd.preparedStatement.setString(5, jtEnd.getText());
					bd.preparedStatement.execute();
					jtNome.setText("");
					jtEmail.setText("");
					jtTelefone.setText("");
					jtCPF.setText("");
					jtEnd.setText("");
					jbAtualiza.setEnabled(false);
					JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso!!");
				} catch (SQLException e) {
					e.printStackTrace();
				}				
			}
		});
		
		jbExibe.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				try {
					bd.sql = "SELECT * FROM cliente WHERE nome LIKE '" + jtNome.getText().toUpperCase() +"%'";
					bd.executaBD("select");
					jtID.setText(bd.id);
					jtNome.setText(bd.nome);
					jtEmail.setText(bd.email);
					jtTelefone.setText(bd.telefone);
					jtCPF.setText(bd.cpf);
					jtEnd.setText(bd.endereco);
					jbAtualiza.setEnabled(true);
				} catch (SQLException e) {
					e.printStackTrace();
				}				
			}
		});
		
		jbAtualiza.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				try {
					bd.sql = "UPDATE cliente SET nome = '" + jtNome.getText().toUpperCase() + "', "
							+ " telefone = '" + jtTelefone.getText() + "', "
							+ " email = '" + jtEmail.getText().toLowerCase() + "', "
							+ "cpf = '" + jtCPF.getText() + "',"
							+ "endereco = '" + jtEnd.getText() + "'"
							+ " WHERE id = '" + Integer.parseInt(jtID.getText()) + "'";
					bd.executaBD("update");
					jtID.setText("");
					jtNome.setText("");
					jtEmail.setText("");
					jtTelefone.setText("");
					jtCPF.setText("");
					jtEnd.setText("");
					JOptionPane.showMessageDialog(null, "Dados alterados com sucesso!!");
					jbAtualiza.setEnabled(false);
				} catch (SQLException e) {
					e.printStackTrace();
				}				
			}
		});		
		
	}	
}
