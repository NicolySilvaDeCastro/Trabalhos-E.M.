package br.com.teste;

public class Testes {
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		TelaInicial tl = new TelaInicial();
	}
}
