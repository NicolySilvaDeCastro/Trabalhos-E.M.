package br.com.teste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class BDUtil {
	String id;
	String nome;
	String email;
	String telefone;
	String cpf;
	String endereco;
	public String sql;
	public Connection connection;
	public PreparedStatement preparedStatement;
	private static final String URL_BD = "jdbc:postgresql://localhost:5432/aula01";
	private static final String USER_BD = "postgres";
	private static final String PASS_BD = "postgres";
	
	public void preparaBD() throws SQLException {
		connection = null;
		preparedStatement = null;		
		connection = DriverManager.getConnection(URL_BD, USER_BD, PASS_BD);
		preparedStatement = connection.prepareStatement(sql);
	}
	public void executaBD(String tipo) throws SQLException {
		connection = null;
		preparedStatement = null;		
		try {
			connection = DriverManager.getConnection(URL_BD, USER_BD, PASS_BD);
			preparedStatement = connection.prepareStatement(sql);			
			if(tipo == "select") {
				ResultSet rs = preparedStatement.executeQuery();
				while(rs.next()) {
					id = rs.getString(1);
					nome = rs.getString(2);
					email = rs.getString(3);
					telefone = rs.getString(4);
					cpf = rs.getString(5);
					endereco = rs.getString(6);
				}
			}else {				
				preparedStatement.execute();
			}
		}catch(SQLException e){
			JOptionPane.showMessageDialog(null, "Problema de acesso ao BD");
			e.printStackTrace();
		}
		finally{
			if(preparedStatement != null) {
				preparedStatement.close();
			}
			if(connection != null) {
				connection.close();
			}
		}
		
	}
}
