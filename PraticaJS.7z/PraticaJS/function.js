// let soma = 0, n1, n2
// n1 = Number(prompt("Digite um número:"))
// n2 = Number(prompt("Digite outro número:"))

// function SomaNumeros(){
//     soma = n1 + n2
// }
// SomaNumeros()
// alert(`A soma entre ${n1} e ${n2} é: ${soma}`)

let  n1, n2
n1 = Number(prompt("Digite um número:"))
n2 = Number(prompt("Digite outro número:"))

function SomaNumeros(a, b){
    soma = a+b
}
SomaNumeros()
alert(`A soma entre ${n1} e ${n2} é: ${SomaNumeros(n1,n2)}`)



