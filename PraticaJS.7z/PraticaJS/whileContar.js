let contar = 1 

while(contar <= 100){
    if(contar % 2 == 0){
        console.log(contar)
    }
    contar ++
}
