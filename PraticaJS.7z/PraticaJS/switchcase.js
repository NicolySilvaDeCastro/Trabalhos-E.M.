let num
num = prompt("Digite um número:")
switch(num){
    case 0:
        alert("Zero")
        break
    case 1:
        alert("Um")
        break
        
    default:
        alert("Número não é binário")
}