let nome = texto = ""

while(nome != "pare"){
nome = prompt("Digite um nome:")
if(nome != "pare")
texto += nome + ","
}

alert(texto)