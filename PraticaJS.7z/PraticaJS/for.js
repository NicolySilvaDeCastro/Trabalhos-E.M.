/*
CONTAGEM COMUM

for(let i = 1; i<=100; i++){
console.log(i)
}

CONTAGEM REGRESSIVA

for(let i = 100; i<=1; i--){
    console.log(i)
}
*/

//MÚLtiplos DE 5

for(let i = 0; i<=100; i+=5){
    console.log(i)
}