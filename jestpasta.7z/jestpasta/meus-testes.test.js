const isEven = require('./index')

// PRIMEIRO TESTE(PARES) VERSÃO EGH

// test('este teste deve verificar se um número e par', () =>{
//     const entrada = 2
//     const saida_esperada = true
//     expect(isEven(entrada)).toEqual(saida_esperada)
// })

// test('este teste deve verificar se um número e par e falhar', () =>{
//     const entrada = 3
//     const saida_esperada = true
//     expect(isEven(entrada)).toEqual(saida_esperada)
// })


// SEGUNDO TESTE(AREAS) VERSÃO TDD

test('deve verificar se a area foi calculada corretamente', () =>{
    const entrada = {
        altura: 10,
        largura: 20,
        raio: 5
    }
    const saida_esperada_quadrado = 200
    const saida_esperada_triangulo = 100
    const saida_esperada_circulo = 100

    expect(calculaArea(entrada, 'quadrado')).toEqual(saida_esperada_quadrado)
    expect(calculaArea(entrada, 'triangulo')).toEqual(saida_esperada_triangulo)
    expect(calculaArea(entrada, 'circulo')).toEqual(saida_esperada_circulo)

})


test('este teste vai verificar se for enviado um objeto errado', () =>{
    const dimensoes = {
        altura: 10,
        largura: 20,
        raio: 5
    }
    const formato = 'hexagono'
    const saida_esperada = 'nao trabalhamos com esse objeto'

    expect(calculaArea(dimensoes, formato)).toEqual(saida_esperada)

})





// MEU RACIOCINIO
// test('testar area do quadrado certo', () =>{
//     const entrada = quadrado; 3; 3; 
//     const saida_esperada = true
//     expect(isEven(entrada)).toEqual(saida_esperada)
// })

// test('testar area do triagulo certo', () =>{
//     const entrada = triangulo; 3; 3; 
//     const saida_esperada = true
//     expect(isEven(entrada)).toEqual(saida_esperada)
// })

// test('testar area do circulo certo', () =>{
//     const entrada = circulo; 3; 
//     const saida_esperada = true
//     expect(isEven(entrada)).toEqual(saida_esperada)
// })



//Comandos do terminal
//npm init -y
// mudar o "test:" do package.json para "test": "jest" 
//npm i jest (para baixar o jest que irá testar o código)
//npm run test (para testar)