// Equipe: Beatriz e Nicoly(3C)

/*
var produto = ['caneta', 'lápis', 'borracha', 'régua', 'caderno', 'lapiseira']
var preco = [5.25, 2.99, 3.99, 5.50, 15.90, 22.59]
var qtdEstoque = [27, 53, 60, 33, 28, 15]

//Função que diz a quantidade do estoque
function compras(qtdComprada, produtoComprado){
    indiceProduto = produto.indexOf(produtoComprado)
    qtdEstoque[indiceProduto] = qtdEstoque[indiceProduto] + qtdComprada
    alert(qtdEstoque[indiceProduto])
}

//Função que diz a quantidade de vendas
function vendas(qtdVendida, produtoVendido){
    indiceProduto = produto.indexOf(produtoVendido)
    qtdEstoque[indiceProduto] = qtdEstoque[indiceProduto] - qtdVendida
    alert(qtdEstoque[indiceProduto])
}

// Função que diz o nome, preço e quantidade do estoque do produto
function novaMercadoria(nomeProduto, precoNovo, qtd){
    var posicao = produto.length
    produto[posicao] = nomeProduto
    preco[posicao] = precoNovo
    qtdEstoque[posicao] = qtd
}

1. Ele gostaria que o sistema possibilitasse a impressão,
 na tela, de um relatório com todas as venda do dia, da papelaria, 
 porém o software não possui uma entrada para a data da venda de um produto.

2.você deve corrigir o que achar que está faltando no software, 
 como por exemplo verificar se o produto possui quantidade suficiente
em estoque antes de realizar uma venda, evitando estoque negativo. 

3. Também deve-se analisar se o produto "novo" que está 
entrando no estoque já não existe no cadastro.*/