export default function Home(){
  return (
    <div className="Home">
      <h1>Bem-vindo ao Site do UNO</h1>
      <p>Explore as páginas para saber mais sobre o jogo de cartas UNO.</p>
    </div>
  );
}

