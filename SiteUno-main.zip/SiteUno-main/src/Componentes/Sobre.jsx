export default function Sobre(){

  return (
    <div className="Sobre">
      <h1>Sobre o UNO</h1>
      <p>O jogo UNO foi criado por Merle Robbins em 1971. Desde então, ele se tornou um dos jogos de cartas mais populares do mundo.</p>
      <p>UNO é conhecido por suas regras simples e por ser um jogo divertido para todas as idades. Ao longo dos anos, várias edições e versões especiais do jogo foram lançadas, adicionando novas cartas e variações das regras.</p>
    </div>
  );
}

