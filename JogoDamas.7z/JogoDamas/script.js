let casa, quebraLinha, pintura = 0, ponto = 0
let tabuleiro = new Array(8)
for(let i = 0; i < tabuleiro.length; i++){
    tabuleiro[i] = new  Array(8)
}

for(let i = 0; i < tabuleiro.length; i++){
    quebraLinha = document.createElement('br')
    document.body.append(quebraLinha)

    for(let j = 0; j < tabuleiro[i].length; j++){
        casa = document.createElement('button')
        casa.setAttribute('id', 'cs' + i + "" + j)
        document.body.append(casa)
        if(pintura % 2 == 0){
            casa.style.background = 'black'
            if(i < 3){
                casa.style.color = "white"
                casa.innerText = "X"
            }
            if(i > 4){
                casa.style.color = "yellow"
                casa.innerText = "o"
            }
        }
        pintura++
        // console.log(`tab ${i} ${j}`)  
        // console.log("tab" + i + "" +j)
         
    }
        pintura++
}

